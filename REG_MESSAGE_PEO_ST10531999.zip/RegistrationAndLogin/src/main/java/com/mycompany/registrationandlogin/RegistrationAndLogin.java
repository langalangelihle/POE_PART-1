package com.mycompany.registrationandlogin;

// Import Scanner class for user input
import java.util.Scanner;

// Public class for user registration and login functionality
public class RegistrationAndLogin {

    // Store registration user cridentials
    static String savedUsername = "";
    static String savedPassword = "";
    static String savedPhone = "";

    //check usename has underscore and is no more than 8 characters
    public static boolean checkUserName(String username) {
        // Check if username contains underscore character
        boolean hasUnderscore = username.contains("_");
        // Check if username length is not more than 8 characters
        boolean correctLength = username.length() <= 8;
        // Return true only if both conditions are met
        return hasUnderscore && correctLength;
    }

    //check password: 11+ charecters, capital letterm, number and a special character
    public static boolean checkPasswordComplexity(String password) {
        // Check if password length is less than 11 characters, return false if it is
        if (password.length() < 11) {
            return false;
        }
        // Initialize boolean variables to track password requirements
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        // Loop through each character in the password
        for (int i = 0; i < password.length(); i++) {
            // Get the current character at position i
            char c = password.charAt(i);
            // Check if character is uppercase letter
            if (Character.isUpperCase(c)) {
                hasCapital = true;
            }
            // Check if character is a digit (0-9)
            if (Character.isDigit(c)) {
                hasNumber = true;
            }
            // Check if character is not a letter or digit (special character)
            if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }
        // Return true only if all three requirements are met
        return hasCapital && hasNumber && hasSpecial;
    }

    //checks phone has international code and is correct in length
    //patten start with '+' followedd by 1-3 digit country code then 9-10 digits
    public static boolean checkCellPhoneNumber(String phone) {
        // Define regex pattern for valid phone format
        String pattern = "^\\+[0-9]{1,3}[0-9]{9,10}$";
        // Check if phone number matches the pattern and return result
        return phone.matches(pattern);
    }

    //returns registration message based on validation results
    public static String registerUser(String username, String password, String phone) {
        // Check if username is not correctly formatted
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your"
                    + " username contains an underscore and is no more than eight"
                    + " characters in length.";
        }
        // Check if password is not correctly formatted
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure the password"
                    + " contains at least eleven characters, a capital letter,"
                    + " a number and a special character.";
        }
        // Check if phone number is not correctly formatted
        if (!checkCellPhoneNumber(phone)) {
            return "Cell phone number is incorrectly formatted or does not contain"
                    + " an international code. Please correct the number and try again.";
        }
        // Return success message if all validations pass
        return "User successfully registered";
    }

    //return TRUE if username and password match saved cridencials
    public static boolean loginUser(String username, String password) {
        // Compare provided username and password with saved credentials
        return savedUsername.equals(username) && savedPassword.equals(password);
    }

    //login success ot failure message
    public static String returnLoginStatus(String username, String password) {
        // Check if login credentials are correct
        if (loginUser(username, password)) {
            // Return welcome message with username if login is successful
            return "Welcome: " + username;
        } else {
            // Return error message if credentials are incorrect
            return "Username or password incorrect, please try again.";
        }
    }

    //Main method
    public static void main(String[] args) {

        //create a new scanner
        Scanner scanner = new Scanner(System.in);

        // Main menu
        boolean running = true;
        while (running) {

            System.out.println("\n--- MAIN MENU ---");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("\nEnter your choice (1, 2 or 3): ");

            String choice = scanner.nextLine();

            switch (choice) {

                case "1":
                    System.out.println("\n--- USER REGISTRATION ---\n");

                    String username = "";
                    while (true) {
                        System.out.print("Enter username (must contain underscore'_' and be max 8 characters): ");
                        username = scanner.nextLine();
                        if (checkUserName(username)) {
                            System.out.println("Username successfully captured.");
                            break;
                        } else {
                            System.out.println("Username is not correctly formatted, please ensure"
                                    + " that your username contains an underscore and is no more"
                                    + " than eight characters in length.");
                        }
                    }

                    String password = "";
                    while (true) {
                        System.out.print("Enter password (11+ chars, capital, number, special char): ");
                        password = scanner.nextLine();
                        if (checkPasswordComplexity(password)) {
                            System.out.println("Password successfully captured.");
                            break;
                        } else {
                            System.out.println("Password is not correctly formatted, please ensure the"
                                    + " password contains at least eleven characters, a capital letter, "
                                    + "a number and a special character.");
                        }
                    }

                    String phone = "";
                    while (true) {
                        System.out.print("Enter cell phone number with international code (e.g. +27611234567): ");
                        phone = scanner.nextLine();
                        if (checkCellPhoneNumber(phone)) {
                            System.out.println("Cell phone number successfully added.");
                            break;
                        } else {
                            System.out.println("Cell phone number is incorrectly formatted or does not contain"
                                    + " international code.");
                        }
                    }

                    // Save all credentials
                    savedUsername = username;
                    savedPassword = password;
                    savedPhone = phone;

                    System.out.println("\n" + registerUser(username, password, phone));
                    break;

                case "2":
                    System.out.println("\n----- USER LOGIN -----\n");

                    // Check if user has registered first
                    if (savedUsername.equals("")) {
                        System.out.println("No account found. Please register first.");
                        break;
                    }

                    // loop keeps running until correct credentials are entered
                    while (true) {
                        System.out.print("Enter your username: ");
                        String loginUsername = scanner.nextLine();

                        System.out.print("Enter your password: ");
                        String loginPassword = scanner.nextLine();

                        String loginStatus = returnLoginStatus(loginUsername, loginPassword);
                        System.out.println("\n" + loginStatus);

                        // If login is successful redirect to Message class GUI
                        if (loginUser(loginUsername, loginPassword)) {
                            // Call the showMenu method from Message class to launch GUI
                            Message.showMenu();
                            // Exit the login loop after returning from Message class
                            break;
                        }

                        // If login failed prompt user to try again
                        System.out.println("\nPlease try again.\n");
                    }
                    break;

                case "3":
                    System.out.println("\nThank you for using the Login App. Goodbye!");
                    // Set running flag to false to exit main loop
                    running = false;
                    break;

                default:
                    //Invalid choice
                    System.out.println("\nInvalid choice. Please enter 1, 2 or 3.");
                    break;
            }
        }

        // Close the Scanner object to release system resources
        scanner.close();
    }
}