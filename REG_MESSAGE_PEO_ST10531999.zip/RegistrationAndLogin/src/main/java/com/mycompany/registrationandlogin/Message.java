package com.mycompany.registrationandlogin;

// Import ArrayList class for storing message data
import java.util.ArrayList;

// Import JOptionPane class for GUI dialog boxes
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.FlowLayout;

// Public class for all messaging functionality using GUI dialogs and array storage
public class Message {

    // ===== SENT MESSAGE ARRAYS =====
    // Static ArrayList to store message IDs of all sent messages
    static ArrayList<String> sentMessageIDs = new ArrayList<>();

    // Static ArrayList to store message hashes of all sent messages
    static ArrayList<String> sentMessageHashes = new ArrayList<>();

    // Static ArrayList to store recipient numbers of all sent messages
    static ArrayList<String> sentRecipients = new ArrayList<>();

    // Static ArrayList to store message text of all sent messages
    static ArrayList<String> sentMessageTexts = new ArrayList<>();

    // ===== STORED MESSAGE ARRAYS =====
    // Static ArrayList to store message IDs of all stored messages
    static ArrayList<String> storedMessageIDs = new ArrayList<>();

    // Static ArrayList to store message hashes of all stored messages
    static ArrayList<String> storedMessageHashes = new ArrayList<>();

    // Static ArrayList to store recipient numbers of all stored messages
    static ArrayList<String> storedRecipients = new ArrayList<>();

    // Static ArrayList to store message text of all stored messages
    static ArrayList<String> storedMessageTexts = new ArrayList<>();

    // Static counter variable to generate unique message IDs starting from 1000
    static int messageIDCounter = 1000;

    // Method to validate that message does not exceed 250 characters
    public static boolean checkMessageLength(String message) {
        // Check if message length is less than or equal to 250 characters
        return message.length() <= 250;
    }

    // Method to validate recipient cell phone number format with international code
    public static boolean checkRecipientCell(String recipient) {
        // Define regex pattern for valid phone: +[1-3 digit country code][9-10 digits]
        String pattern = "^\\+[0-9]{1,3}[0-9]{9,10}$";
        // Check if recipient phone matches the pattern and return result
        return recipient.matches(pattern);
    }

    // Method to create message hash using messageID, message count, and message words
    public static String createMessageHash(String messageID, int numMessages, String message) {
        // Split message string into individual words using space delimiter
        String[] words = message.split(" ");
        // Get the first word from the message, or empty string if no words exist
        String firstWord = words.length > 0 ? words[0] : "";
        // Get the last word from the message, or empty string if no words exist
        String lastWord = words.length > 0 ? words[words.length - 1] : "";
        // Create and return hash in format: first2CharsOfID:messageCount:firstWord:lastWord
        return messageID.substring(0, 2) + ":" + numMessages + ":" + firstWord + ":" + lastWord;
    }

    // Method to generate unique message ID by incrementing counter
    public static String generateMessageID() {
        // Increment the messageIDCounter by 1
        messageIDCounter++;
        // Convert the incremented counter to string and return as message ID
        return String.valueOf(messageIDCounter);
    }

    // Method to return the total count of messages that have been sent
    public static int returnTotalMessagesSent() {
        // Return the size of sentMessageIDs ArrayList
        return sentMessageIDs.size();
    }

    // Method to handle sending a new message using GUI dialogs
    public static void sendNewMessage() {

        // Variable to store the recipient phone number
        String recipient = "";

        // Loop until valid recipient phone number is entered
        while (true) {
            // Show GUI input dialog asking user to enter recipient phone number
            recipient = JOptionPane.showInputDialog(null,
                    "Enter recipient cell phone number with international code (e.g. +27611234567):",
                    "Send New Message",
                    JOptionPane.PLAIN_MESSAGE);

            // Check if user clicked Cancel or closed the dialog
            if (recipient == null) {
                // Return from method if user cancelled
                return;
            }

            // Validate recipient phone number using checkRecipientCell method
            if (checkRecipientCell(recipient)) {
                // Show success message dialog if phone number is valid
                JOptionPane.showMessageDialog(null,
                        "Recipient successfully added.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                // Exit loop if valid phone number is entered
                break;
            } else {
                // Show error message dialog if phone number format is invalid
                JOptionPane.showMessageDialog(null,
                        "Cell phone number is incorrectly formatted or does not contain"
                        + " an international code. Please try again.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        // Variable to store the message text content
        String messageText = "";

        // Loop until valid message is entered
        while (true) {
            // Show GUI input dialog asking user to enter message text
            messageText = JOptionPane.showInputDialog(null,
                    "Enter your message (max 250 characters):",
                    "Send New Message",
                    JOptionPane.PLAIN_MESSAGE);

            // Check if user clicked Cancel or closed the dialog
            if (messageText == null) {
                // Return from method if user cancelled
                return;
            }

            // Validate message length using checkMessageLength method
            if (checkMessageLength(messageText)) {
                // Show success message dialog if message length is valid
                JOptionPane.showMessageDialog(null,
                        "Message successfully captured.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
                // Exit loop if valid message is entered
                break;
            } else {
                // Show error message dialog if message exceeds 250 characters
                JOptionPane.showMessageDialog(null,
                        "Please enter a message of less than 250 characters.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        // Generate unique message ID using generateMessageID method
        String messageID = generateMessageID();

        // Calculate the number of messages sent so far plus this new one
        int numMessages = sentMessageIDs.size() + 1;

        // Create message hash using createMessageHash method
        String messageHash = createMessageHash(messageID, numMessages, messageText);

        // Display message details in a GUI message dialog
        JOptionPane.showMessageDialog(null,
                "Message ID: " + messageID + "\n"
                + "Message Hash: " + messageHash + "\n"
                + "Recipient: " + recipient + "\n"
                + "Message: " + messageText,
                "Message Details",
                JOptionPane.INFORMATION_MESSAGE);

        // Define the action options for the option dialog
        String[] actionOptions = {"Send Message", "Discard Message", "Store Message"};

        // Show GUI option dialog asking user what to do with the message
        int action = JOptionPane.showOptionDialog(null,
                "What would you like to do with this message?",
                "Select Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                actionOptions,
                actionOptions[0]);

        // Switch statement to handle user's selected action
        switch (action) {

            case 0:
                // Case 0: User selected Send Message
                // Add message ID to sentMessageIDs ArrayList
                sentMessageIDs.add(messageID);
                // Add message hash to sentMessageHashes ArrayList
                sentMessageHashes.add(messageHash);
                // Add recipient to sentRecipients ArrayList
                sentRecipients.add(recipient);
                // Add message text to sentMessageTexts ArrayList
                sentMessageTexts.add(messageText);
                // Show success dialog confirming message was sent
                JOptionPane.showMessageDialog(null,
                        "Message successfully sent.",
                        "Sent",
                        JOptionPane.INFORMATION_MESSAGE);
                // End case 0
                break;

            case 1:
                // Case 1: User selected Discard Message
                // Show confirm dialog asking user to confirm deletion
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Are you sure you want to delete this message?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION);
                // Check if user confirmed the deletion
                if (confirm == JOptionPane.YES_OPTION) {
                    // Show message dialog confirming message was deleted
                    JOptionPane.showMessageDialog(null,
                            "Message has been deleted.",
                            "Deleted",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                // End case 1
                break;

            case 2:
                // Case 2: User selected Store Message
                // Add message ID to storedMessageIDs ArrayList
                storedMessageIDs.add(messageID);
                // Add message hash to storedMessageHashes ArrayList
                storedMessageHashes.add(messageHash);
                // Add recipient to storedRecipients ArrayList
                storedRecipients.add(recipient);
                // Add message text to storedMessageTexts ArrayList
                storedMessageTexts.add(messageText);
                // Show success dialog confirming message was stored
                JOptionPane.showMessageDialog(null,
                        "Message successfully stored.",
                        "Stored",
                        JOptionPane.INFORMATION_MESSAGE);
                // End case 2
                break;

            default:
                // Default case: User closed the dialog without selecting
                // Show message dialog informing user message was discarded
                JOptionPane.showMessageDialog(null,
                        "No action selected. Message discarded.",
                        "Discarded",
                        JOptionPane.WARNING_MESSAGE);
                // End default case
                break;
        }
    }

    // ===== REQUIREMENT A: Display sender and recipient of all stored messages =====
    public static void displayStoredMessageSenders() {

        // Check if there are any stored messages
        if (storedMessageIDs.isEmpty()) {
            // Show message dialog if no messages are stored
            JOptionPane.showMessageDialog(null,
                    "No stored messages.",
                    "Stored Message Senders & Recipients",
                    JOptionPane.INFORMATION_MESSAGE);
            // Return from method since there is nothing to display
            return;
        }

        // Create a StringBuilder to build the display text
        StringBuilder sb = new StringBuilder();

        // Append section header
        sb.append("--- STORED MESSAGE SENDERS & RECIPIENTS ---\n\n");

        // Loop through each stored message
        for (int i = 0; i < storedMessageIDs.size(); i++) {
            // Append message number
            sb.append("Message #").append(i + 1).append("\n");
            // Append message ID
            sb.append("Message ID: ").append(storedMessageIDs.get(i)).append("\n");
            // Append recipient (sender perspective: who we're sending to)
            sb.append("Recipient: ").append(storedRecipients.get(i)).append("\n");
            // Append separator line
            sb.append("---\n");
        }

        // Show all stored message senders/recipients in a GUI message dialog
        JOptionPane.showMessageDialog(null,
                sb.toString(),
                "Stored Message Senders & Recipients",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // ===== REQUIREMENT B: Display the longest stored message =====
    public static void displayLongestStoredMessage() {

        // Check if there are any stored messages
        if (storedMessageIDs.isEmpty()) {
            // Show message dialog if no messages are stored
            JOptionPane.showMessageDialog(null,
                    "No stored messages.",
                    "Longest Stored Message",
                    JOptionPane.INFORMATION_MESSAGE);
            // Return from method since there is nothing to display
            return;
        }

        // Variable to track the longest message found
        String longestMessage = "";
        // Variable to track the index of the longest message
        int longestIndex = 0;

        // Loop through all stored messages to find the longest one
        for (int i = 0; i < storedMessageTexts.size(); i++) {
            // Compare current message length with longest message found so far
            if (storedMessageTexts.get(i).length() > longestMessage.length()) {
                // Update longest message if current message is longer
                longestMessage = storedMessageTexts.get(i);
                // Update the index to track which message is longest
                longestIndex = i;
            }
        }

        // Create StringBuilder to build the display text for the longest message
        StringBuilder sb = new StringBuilder();

        // Append header
        sb.append("--- LONGEST STORED MESSAGE ---\n\n");
        // Append message ID
        sb.append("Message ID: ").append(storedMessageIDs.get(longestIndex)).append("\n");
        // Append message hash
        sb.append("Message Hash: ").append(storedMessageHashes.get(longestIndex)).append("\n");
        // Append recipient
        sb.append("Recipient: ").append(storedRecipients.get(longestIndex)).append("\n");
        // Append message text
        sb.append("Message: ").append(longestMessage).append("\n");
        // Append message length in characters
        sb.append("Length: ").append(longestMessage.length()).append(" characters");

        // Show the longest message in a GUI message dialog
        JOptionPane.showMessageDialog(null,
                sb.toString(),
                "Longest Stored Message",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // ===== REQUIREMENT C: Search for message by ID =====
    public static void searchStoredMessageByID() {

        // Check if there are any stored messages
        if (storedMessageIDs.isEmpty()) {
            // Show message dialog if no messages are stored
            JOptionPane.showMessageDialog(null,
                    "No stored messages.",
                    "Search Message by ID",
                    JOptionPane.INFORMATION_MESSAGE);
            // Return from method since there is nothing to search
            return;
        }

        // Show GUI input dialog asking user to enter the message ID to search for
        String searchID = JOptionPane.showInputDialog(null,
                "Enter the message ID to search for:",
                "Search Message by ID",
                JOptionPane.PLAIN_MESSAGE);

        // Check if user clicked Cancel or closed the dialog
        if (searchID == null) {
            // Return from method if user cancelled
            return;
        }

        // Loop through all stored messages to find matching ID
        for (int i = 0; i < storedMessageIDs.size(); i++) {
            // Check if current message ID matches the search ID
            if (storedMessageIDs.get(i).equals(searchID)) {
                // Create StringBuilder to build the display text
                StringBuilder sb = new StringBuilder();

                // Append header
                sb.append("--- MESSAGE FOUND ---\n\n");
                // Append message ID
                sb.append("Message ID: ").append(storedMessageIDs.get(i)).append("\n");
                // Append recipient
                sb.append("Recipient: ").append(storedRecipients.get(i)).append("\n");
                // Append message text
                sb.append("Message: ").append(storedMessageTexts.get(i));

                // Show the found message in a GUI message dialog
                JOptionPane.showMessageDialog(null,
                        sb.toString(),
                        "Search Result",
                        JOptionPane.INFORMATION_MESSAGE);
                // Return from method after finding the message
                return;
            }
        }

        // If loop completes without finding message, show not found dialog
        JOptionPane.showMessageDialog(null,
                "No message found with ID: " + searchID,
                "Search Result",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // ===== REQUIREMENT D: Search for all messages for a particular recipient =====
    public static void searchStoredMessagesByRecipient() {

        // Check if there are any stored messages
        if (storedMessageIDs.isEmpty()) {
            // Show message dialog if no messages are stored
            JOptionPane.showMessageDialog(null,
                    "No stored messages.",
                    "Search Messages by Recipient",
                    JOptionPane.INFORMATION_MESSAGE);
            // Return from method since there is nothing to search
            return;
        }

        // Show GUI input dialog asking user to enter the recipient to search for
        String searchRecipient = JOptionPane.showInputDialog(null,
                "Enter the recipient phone number to search for:",
                "Search Messages by Recipient",
                JOptionPane.PLAIN_MESSAGE);

        // Check if user clicked Cancel or closed the dialog
        if (searchRecipient == null) {
            // Return from method if user cancelled
            return;
        }

        // Create ArrayList to store all matching messages
        ArrayList<Integer> matchingIndices = new ArrayList<>();

        // Loop through all stored messages to find matching recipient
        for (int i = 0; i < storedRecipients.size(); i++) {
            // Check if current recipient matches the search recipient
            if (storedRecipients.get(i).equals(searchRecipient)) {
                // Add index to matching indices list
                matchingIndices.add(i);
            }
        }

        // Check if any messages were found for the recipient
        if (matchingIndices.isEmpty()) {
            // Show message dialog if no messages found
            JOptionPane.showMessageDialog(null,
                    "No messages found for recipient: " + searchRecipient,
                    "Search Result",
                    JOptionPane.INFORMATION_MESSAGE);
            // Return from method
            return;
        }

        // Create StringBuilder to build the display text for all matching messages
        StringBuilder sb = new StringBuilder();

        // Append header
        sb.append("--- MESSAGES FOR RECIPIENT: ").append(searchRecipient).append(" ---\n\n");

        // Loop through all matching messages and append their details
        for (int i = 0; i < matchingIndices.size(); i++) {
            // Get the actual index from the matching indices list
            int index = matchingIndices.get(i);
            // Append message number
            sb.append("Message #").append(i + 1).append("\n");
            // Append message ID
            sb.append("Message ID: ").append(storedMessageIDs.get(index)).append("\n");
            // Append message text
            sb.append("Message: ").append(storedMessageTexts.get(index)).append("\n");
            // Append separator line
            sb.append("---\n");
        }

        // Show all matching messages in a GUI message dialog
        JOptionPane.showMessageDialog(null,
                sb.toString(),
                "Search Results",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // ===== REQUIREMENT E: Delete message using message hash =====
    public static void deleteStoredMessageByHash() {

        // Check if there are any stored messages
        if (storedMessageIDs.isEmpty()) {
            // Show message dialog if no messages are stored
            JOptionPane.showMessageDialog(null,
                    "No stored messages.",
                    "Delete Message",
                    JOptionPane.INFORMATION_MESSAGE);
            // Return from method since there is nothing to delete
            return;
        }

        // Show GUI input dialog asking user to enter the message hash to delete
        String searchHash = JOptionPane.showInputDialog(null,
                "Enter the message hash to delete:",
                "Delete Message",
                JOptionPane.PLAIN_MESSAGE);

        // Check if user clicked Cancel or closed the dialog
        if (searchHash == null) {
            // Return from method if user cancelled
            return;
        }

        // Loop through all stored messages to find matching hash
        for (int i = 0; i < storedMessageHashes.size(); i++) {
            // Check if current message hash matches the search hash (case-insensitive)
            if (storedMessageHashes.get(i).equalsIgnoreCase(searchHash)) {
                // Show confirm dialog asking user to confirm deletion
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Are you sure you want to delete this message?\n"
                        + "Message: " + storedMessageTexts.get(i),
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION);

                // Check if user confirmed the deletion
                if (confirm == JOptionPane.YES_OPTION) {
                    // Remove message from all stored arrays at the found index
                    storedMessageIDs.remove(i);
                    storedMessageHashes.remove(i);
                    storedRecipients.remove(i);
                    storedMessageTexts.remove(i);

                    // Show message dialog confirming message was deleted
                    JOptionPane.showMessageDialog(null,
                            "Message deleted successfully!",
                            "Deleted",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                // Return from method after handling deletion
                return;
            }
        }

        // If loop completes without finding hash, show not found dialog
        JOptionPane.showMessageDialog(null,
                "No message found with hash: " + searchHash,
                "Search Result",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // ===== REQUIREMENT F: Display full report of all stored messages =====
    public static void displayStoredMessagesFullReport() {

        // Check if there are any stored messages
        if (storedMessageIDs.isEmpty()) {
            // Show message dialog if no messages are stored
            JOptionPane.showMessageDialog(null,
                    "No stored messages.",
                    "Full Report",
                    JOptionPane.INFORMATION_MESSAGE);
            // Return from method since there is nothing to report
            return;
        }

        // Create StringBuilder to build the full report text
        StringBuilder sb = new StringBuilder();

        // Append report header
        sb.append("========= STORED MESSAGES FULL REPORT =========\n\n");

        // Loop through each stored message and append its full details
        for (int i = 0; i < storedMessageIDs.size(); i++) {
            // Append message number
            sb.append("Message #").append(i + 1).append("\n");
            // Append message ID
            sb.append("Message ID: ").append(storedMessageIDs.get(i)).append("\n");
            // Append message hash
            sb.append("Message Hash: ").append(storedMessageHashes.get(i)).append("\n");
            // Append recipient phone number
            sb.append("Recipient: ").append(storedRecipients.get(i)).append("\n");
            // Append message text
            sb.append("Message: ").append(storedMessageTexts.get(i)).append("\n");
            // Append separator line between messages
            sb.append("---\n");
        }

        // Append total count of stored messages at the end
        sb.append("\nTotal stored messages: ").append(storedMessageIDs.size());
        sb.append("\n===============================================");

        // Show the full report in a GUI message dialog
        JOptionPane.showMessageDialog(null,
                sb.toString(),
                "Full Report",
                JOptionPane.INFORMATION_MESSAGE);
    }

    // Method to display and manage stored messages with send/delete options
    public static void manageStoredMessages() {

        // Check if there are any stored messages
        if (storedMessageIDs.isEmpty()) {
            // Show message dialog if no messages are stored
            JOptionPane.showMessageDialog(null,
                    "No stored messages.",
                    "Stored Messages",
                    JOptionPane.INFORMATION_MESSAGE);
            // Return from method since there is nothing to manage
            return;
        }

        // Create a StringBuilder to build the list of stored messages with numbers
        StringBuilder sb = new StringBuilder();

        // Append header
        sb.append("--- STORED MESSAGES ---\n\n");

        // Loop through each stored message and append with number
        for (int i = 0; i < storedMessageIDs.size(); i++) {
            // Append message number, ID, recipient, and text preview
            sb.append(i + 1).append(". ID: ").append(storedMessageIDs.get(i))
                    .append(" | Recipient: ").append(storedRecipients.get(i))
                    .append(" | Message: ").append(storedMessageTexts.get(i)).append("\n");
        }

        // Show the list of stored messages and ask user to select one
        String selection = JOptionPane.showInputDialog(null,
                sb.toString() + "\nEnter message number (1-" + storedMessageIDs.size() + "):",
                "Stored Messages",
                JOptionPane.PLAIN_MESSAGE);

        // Check if user clicked Cancel or closed the dialog
        if (selection == null) {
            // Return from method if user cancelled
            return;
        }

        // Variable to track the selected message index
        int selectedIndex = -1;

        // Try to parse the user input as an integer
        try {
            // Convert string input to integer
            int selectedNumber = Integer.parseInt(selection);
            // Check if number is within valid range (1 to size)
            if (selectedNumber >= 1 && selectedNumber <= storedMessageIDs.size()) {
                // Convert to 0-based index
                selectedIndex = selectedNumber - 1;
            } else {
                // Show error if number is out of range
                JOptionPane.showMessageDialog(null,
                        "Invalid selection. Please enter a valid number.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                // Return from method
                return;
            }
        } catch (NumberFormatException e) {
            // Show error if input is not a number
            JOptionPane.showMessageDialog(null,
                    "Invalid input. Please enter a number.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            // Return from method
            return;
        }

        // Create StringBuilder to display the selected message details
        StringBuilder messageDetails = new StringBuilder();

        // Append header
        messageDetails.append("--- MESSAGE DETAILS ---\n\n");
        // Append message ID
        messageDetails.append("Message ID: ").append(storedMessageIDs.get(selectedIndex)).append("\n");
        // Append message hash
        messageDetails.append("Message Hash: ").append(storedMessageHashes.get(selectedIndex)).append("\n");
        // Append recipient
        messageDetails.append("Recipient: ").append(storedRecipients.get(selectedIndex)).append("\n");
        // Append message text
        messageDetails.append("Message: ").append(storedMessageTexts.get(selectedIndex));

        // Define the action options for stored message
        String[] actionOptions = {"Send Now", "Delete Message", "Cancel"};

        // Show GUI option dialog asking user what to do with the stored message
        int action = JOptionPane.showOptionDialog(null,
                messageDetails.toString() + "\n\nWhat would you like to do?",
                "Stored Message Action",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                actionOptions,
                actionOptions[0]);

        // Switch statement to handle user's selected action
        switch (action) {

            case 0:
                // Case 0: User selected Send Now
                // Add message to sent arrays
                sentMessageIDs.add(storedMessageIDs.get(selectedIndex));
                sentMessageHashes.add(storedMessageHashes.get(selectedIndex));
                sentRecipients.add(storedRecipients.get(selectedIndex));
                sentMessageTexts.add(storedMessageTexts.get(selectedIndex));

                // Remove message from stored arrays
                storedMessageIDs.remove(selectedIndex);
                storedMessageHashes.remove(selectedIndex);
                storedRecipients.remove(selectedIndex);
                storedMessageTexts.remove(selectedIndex);

                // Show success dialog confirming message was sent
                JOptionPane.showMessageDialog(null,
                        "Message sent successfully!",
                        "Sent",
                        JOptionPane.INFORMATION_MESSAGE);
                // End case 0
                break;

            case 1:
                // Case 1: User selected Delete Message
                // Show confirm dialog asking user to confirm deletion
                int confirm = JOptionPane.showConfirmDialog(null,
                        "Are you sure you want to delete this message?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION);

                // Check if user confirmed the deletion
                if (confirm == JOptionPane.YES_OPTION) {
                    // Remove message from all stored arrays at the selected index
                    storedMessageIDs.remove(selectedIndex);
                    storedMessageHashes.remove(selectedIndex);
                    storedRecipients.remove(selectedIndex);
                    storedMessageTexts.remove(selectedIndex);

                    // Show message dialog confirming message was deleted
                    JOptionPane.showMessageDialog(null,
                            "Message deleted successfully!",
                            "Deleted",
                            JOptionPane.INFORMATION_MESSAGE);
                }
                // End case 1
                break;

            case 2:
            default:
                // Case 2 / Default: User selected Cancel or closed dialog
                // Just return without making any changes
                break;
        }
    }

    // Method to display the Message Manager submenu with horizontal buttons
    public static void showMessageManagerMenu() {

        // Initialize boolean flag to control message manager menu loop
        boolean running = true;

        // Message Manager menu loop - continues until user selects back
        while (running) {

            // Create custom panel with FlowLayout for horizontal button arrangement
            JPanel panel = new JPanel();
            panel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));

            // Create array of button labels
            String[] buttonLabels = {
                "a. Display sender/recipient",
                "b. Longest message",
                "c. Search by ID",
                "d. Search by recipient",
                "e. Delete by hash",
                "f. Full report",
                "Back to Main Menu"
            };

            // Array to store button references
            JButton[] buttons = new JButton[buttonLabels.length];

            // Variable to track which button was clicked
            final int[] selectedChoice = {-1};

            // Create and add buttons to panel
            for (int i = 0; i < buttonLabels.length; i++) {
                final int index = i;
                buttons[i] = new JButton(buttonLabels[i]);
                buttons[i].addActionListener(e -> {
                    selectedChoice[0] = index;
                });
                panel.add(buttons[i]);
            }

            // Show dialog with custom panel containing horizontal buttons
            int result = JOptionPane.showOptionDialog(null,
                    panel,
                    "Message Manager - Select an option:",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    new String[]{},
                    null);

            // If user closed dialog, set to back option
            if (result == JOptionPane.CLOSED_OPTION && selectedChoice[0] == -1) {
                running = false;
                break;
            }

            // If no button was clicked, treat as back
            if (selectedChoice[0] == -1) {
                running = false;
                break;
            }

            // Switch statement to handle user's menu choice
            switch (selectedChoice[0]) {

                case 0:
                    // Case 0: Requirement A - Display senders/recipients
                    displayStoredMessageSenders();
                    break;

                case 1:
                    // Case 1: Requirement B - Display longest message
                    displayLongestStoredMessage();
                    break;

                case 2:
                    // Case 2: Requirement C - Search message by ID
                    searchStoredMessageByID();
                    break;

                case 3:
                    // Case 3: Requirement D - Search messages by recipient
                    searchStoredMessagesByRecipient();
                    break;

                case 4:
                    // Case 4: Requirement E - Delete message by hash
                    deleteStoredMessageByHash();
                    break;

                case 5:
                    // Case 5: Requirement F - Display full report
                    displayStoredMessagesFullReport();
                    break;

                case 6:
                    // Case 6: Back to Main Menu
                    running = false;
                    break;

                default:
                    // Default case: Treat as back
                    running = false;
                    break;
            }
        }
    }

    // Method to display the main QuickChat menu as GUI after successful login
    public static void showMenu() {

        // Initialize boolean flag to control message menu loop
        boolean running = true;

        // Message menu loop - continues until user selects exit
        while (running) {

            // Define the main menu button options for the option dialog
            String[] menuOptions = {"Send Message", "Message Manager", "Exit"};

            // Show GUI option dialog for the main menu
            int choice = JOptionPane.showOptionDialog(null,
                    "Welcome to QuickChat!\nSelect an option:",
                    "QuickChat - Main Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    menuOptions,
                    menuOptions[0]);

            // Switch statement to handle user's menu choice
            switch (choice) {

                case 0:
                    // Case 0: User selected Send Message
                    // Call sendNewMessage method to handle the send message flow
                    sendNewMessage();
                    // End case 0
                    break;

                case 1:
                    // Case 1: User selected Message Manager
                    // Call showMessageManagerMenu method to display the Message Manager submenu
                    showMessageManagerMenu();
                    // End case 1
                    break;

                case 2:
                    // Case 2: User selected Exit
                    // Show goodbye message dialog to the user
                    JOptionPane.showMessageDialog(null,
                            "Thank you for using the app good bye",
                            "Goodbye",
                            JOptionPane.INFORMATION_MESSAGE);
                    // Set running flag to false to exit the menu loop
                    running = false;
                    // End case 2
                    break;

                default:
                    // Default case: User closed the dialog without selecting
                    // Show goodbye message and exit if dialog is closed
                    JOptionPane.showMessageDialog(null,
                            "Thank you for using the app good bye",
                            "Goodbye",
                            JOptionPane.INFORMATION_MESSAGE);
                    // Set running flag to false to exit the menu loop
                    running = false;
                    // End default case
                    break;
            }
        }
    }
}