package com.mycompany.registrationandlogin;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lsphe
 */
// Declare the RegistrationAndLoginTest class for unit testing the RegistrationAndLogin class
public class RegistrationAndLoginTest {
    
    // Default constructor for RegistrationAndLoginTest class
    public RegistrationAndLoginTest() {
    }
    
    // Setup method that runs once before all test methods in the class
    @BeforeAll
    public static void setUpClass() {
    }
    
    // Teardown method that runs once after all test methods in the class
    @AfterAll
    public static void tearDownClass() {
    }
    
    // Setup method that runs before each individual test method
    @BeforeEach
    public void setUp() {
        // Reset saved username to empty string before each test to ensure clean state
        RegistrationAndLogin.savedUsername = "";
        // Reset saved password to empty string before each test to ensure clean state
        RegistrationAndLogin.savedPassword = "";
        // Reset saved phone number to empty string before each test to ensure clean state
        RegistrationAndLogin.savedPhone = "";
    }
    
    // Teardown method that runs after each individual test method
    @AfterEach
    public void tearDown() {
        // Clear saved username after test execution to clean up
        RegistrationAndLogin.savedUsername = "";
        // Clear saved password after test execution to clean up
        RegistrationAndLogin.savedPassword = "";
        // Clear saved phone number after test execution to clean up
        RegistrationAndLogin.savedPhone = "";
    }

    // ===== checkUserName() TESTS =====
    
    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkUserName accepts valid username with underscore
    public void testCheckUserNameValid() {
        // Print test name to console for tracking test execution
        System.out.println("checkUserName - Valid");
        // Create a valid test username with underscore and within 8 character limit
        String username = "user_123";
        // Call checkUserName method with test username and store result
        boolean result = RegistrationAndLogin.checkUserName(username);
        // Assert that result is true since username contains underscore and is within length limit
        assertTrue(result, "Username with underscore and valid length should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkUserName accepts short valid usernames
    public void testCheckUserNameValidShort() {
        // Print test name to console for tracking test execution
        System.out.println("checkUserName - Valid Short");
        // Create a short valid test username with underscore
        String username = "usr_ab";
        // Call checkUserName method with test username and store result
        boolean result = RegistrationAndLogin.checkUserName(username);
        // Assert that result is true since short username with underscore is valid
        assertTrue(result, "Username with underscore and less than 8 chars should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkUserName accepts username with exactly 8 characters
    public void testCheckUserNameExactly8Chars() {
        // Print test name to console for tracking test execution
        System.out.println("checkUserName - Exactly 8 Characters");
        // Create a test username with exactly 8 characters and underscore
        String username = "user_abc";
        // Call checkUserName method with test username and store result
        boolean result = RegistrationAndLogin.checkUserName(username);
        // Assert that result is true since 8 characters is the maximum allowed length
        assertTrue(result, "Username with exactly 8 characters and underscore should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkUserName rejects username without underscore
    public void testCheckUserNameMissingUnderscore() {
        // Print test name to console for tracking test execution
        System.out.println("checkUserName - Missing Underscore");
        // Create a test username without underscore (invalid)
        String username = "username";
        // Call checkUserName method with test username and store result
        boolean result = RegistrationAndLogin.checkUserName(username);
        // Assert that result is false since underscore is required
        assertFalse(result, "Username without underscore should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkUserName rejects username longer than 8 characters
    public void testCheckUserNameTooLong() {
        // Print test name to console for tracking test execution
        System.out.println("checkUserName - Too Long (9 chars)");
        // Create a test username with 9 characters exceeding the 8 character limit
        String username = "user_1234";
        // Call checkUserName method with test username and store result
        boolean result = RegistrationAndLogin.checkUserName(username);
        // Assert that result is false since username exceeds 8 character maximum
        assertFalse(result, "Username longer than 8 characters should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkUserName rejects empty string
    public void testCheckUserNameEmptyString() {
        // Print test name to console for tracking test execution
        System.out.println("checkUserName - Empty String");
        // Create an empty string as test username (invalid)
        String username = "";
        // Call checkUserName method with empty username and store result
        boolean result = RegistrationAndLogin.checkUserName(username);
        // Assert that result is false since empty string does not contain underscore
        assertFalse(result, "Empty username should return false");
    }

    // ===== checkPasswordComplexity() TESTS =====
    
    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkPasswordComplexity accepts valid password
    public void testCheckPasswordComplexityValid() {
        // Print test name to console for tracking test execution
        System.out.println("checkPasswordComplexity - Valid");
        // Create a valid password with capital letter, number, and special character
        String password = "SecurePass123!";
        // Call checkPasswordComplexity method with test password and store result
        boolean result = RegistrationAndLogin.checkPasswordComplexity(password);
        // Assert that result is true since password meets all complexity requirements
        assertTrue(result, "Password with capital, number, and special char should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkPasswordComplexity accepts longer valid passwords
    public void testCheckPasswordComplexityValidLong() {
        // Print test name to console for tracking test execution
        System.out.println("checkPasswordComplexity - Valid Long");
        // Create a longer valid password with all requirements
        String password = "SecurePassword123@#$";
        // Call checkPasswordComplexity method with test password and store result
        boolean result = RegistrationAndLogin.checkPasswordComplexity(password);
        // Assert that result is true since longer password meets all complexity requirements
        assertTrue(result, "Longer password with all requirements should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkPasswordComplexity accepts password with exactly 11 characters
    public void testCheckPasswordComplexityExactly11Chars() {
        // Print test name to console for tracking test execution
        System.out.println("checkPasswordComplexity - Exactly 11 Characters");
        // Create a password with exactly 11 characters and all requirements
        String password = "Secure123!a";
        // Call checkPasswordComplexity method with test password and store result
        boolean result = RegistrationAndLogin.checkPasswordComplexity(password);
        // Assert that result is true since 11 characters is minimum length requirement
        assertTrue(result, "Password with exactly 11 characters and all requirements should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkPasswordComplexity rejects password shorter than 11 characters
    public void testCheckPasswordComplexityTooShort() {
        // Print test name to console for tracking test execution
        System.out.println("checkPasswordComplexity - Too Short (10 chars)");
        // Create a password with only 10 characters (less than 11 minimum)
        String password = "Pass123!ab";
        // Call checkPasswordComplexity method with test password and store result
        boolean result = RegistrationAndLogin.checkPasswordComplexity(password);
        // Assert that result is false since password is shorter than 11 character minimum
        assertFalse(result, "Password with less than 11 characters should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkPasswordComplexity rejects password without capital letter
    public void testCheckPasswordComplexityNoCapital() {
        // Print test name to console for tracking test execution
        System.out.println("checkPasswordComplexity - No Capital Letter");
        // Create a password without any uppercase letters (invalid)
        String password = "password123!abc";
        // Call checkPasswordComplexity method with test password and store result
        boolean result = RegistrationAndLogin.checkPasswordComplexity(password);
        // Assert that result is false since password lacks required capital letter
        assertFalse(result, "Password without capital letter should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkPasswordComplexity rejects password without number
    public void testCheckPasswordComplexityNoNumber() {
        // Print test name to console for tracking test execution
        System.out.println("checkPasswordComplexity - No Number");
        // Create a password without any numeric digits (invalid)
        String password = "PasswordSpecial!abc";
        // Call checkPasswordComplexity method with test password and store result
        boolean result = RegistrationAndLogin.checkPasswordComplexity(password);
        // Assert that result is false since password lacks required number
        assertFalse(result, "Password without number should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkPasswordComplexity rejects password without special character
    public void testCheckPasswordComplexityNoSpecialChar() {
        // Print test name to console for tracking test execution
        System.out.println("checkPasswordComplexity - No Special Character");
        // Create a password without any special characters (invalid)
        String password = "Password123abcde";
        // Call checkPasswordComplexity method with test password and store result
        boolean result = RegistrationAndLogin.checkPasswordComplexity(password);
        // Assert that result is false since password lacks required special character
        assertFalse(result, "Password without special character should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkPasswordComplexity rejects empty string
    public void testCheckPasswordComplexityEmptyString() {
        // Print test name to console for tracking test execution
        System.out.println("checkPasswordComplexity - Empty String");
        // Create an empty string as test password (invalid)
        String password = "";
        // Call checkPasswordComplexity method with empty password and store result
        boolean result = RegistrationAndLogin.checkPasswordComplexity(password);
        // Assert that result is false since empty string fails all complexity requirements
        assertFalse(result, "Empty password should return false");
    }

    // ===== checkCellPhoneNumber() TESTS =====
    
    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber accepts valid South African phone
    public void testCheckCellPhoneNumberValidSouthAfrica() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - Valid South Africa");
        // Create a valid South African phone number with country code
        String phone = "+27611234567";
        // Call checkCellPhoneNumber method with test phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is true since South African phone format is valid
        assertTrue(result, "Valid South African phone number should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber accepts valid UK phone
    public void testCheckCellPhoneNumberValidUK() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - Valid UK");
        // Create a valid UK phone number with country code
        String phone = "+441234567890";
        // Call checkCellPhoneNumber method with test phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is true since UK phone format is valid
        assertTrue(result, "Valid UK phone number should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber accepts valid USA phone
    public void testCheckCellPhoneNumberValidUSA() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - Valid USA");
        // Create a valid USA phone number with country code
        String phone = "+12025550123";
        // Call checkCellPhoneNumber method with test phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is true since USA phone format is valid
        assertTrue(result, "Valid USA phone number should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber rejects phone without plus sign
    public void testCheckCellPhoneNumberMissingPlus() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - Missing Plus Sign");
        // Create a phone number without the required plus sign (invalid)
        String phone = "27611234567";
        // Call checkCellPhoneNumber method with test phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is false since plus sign is required
        assertFalse(result, "Phone number without + should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber rejects phone with too few digits
    public void testCheckCellPhoneNumberTooShort() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - Too Short (8 digits)");
        // Create a phone number with insufficient digits (invalid)
        String phone = "+276112345";
        // Call checkCellPhoneNumber method with test phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is false since phone has less than 9 required digits
        assertFalse(result, "Phone number with less than 9 digits should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber rejects phone with too many digits
    public void testCheckCellPhoneNumberTooLong() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - Too Long (11 digits)");
        // Create a phone number with too many digits (invalid)
        String phone = "+276112345678";
        // Call checkCellPhoneNumber method with test phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is false since phone has more than 10 allowed digits
        assertFalse(result, "Phone number with more than 10 digits should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber rejects invalid country code format
    public void testCheckCellPhoneNumberInvalidCountryCode() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - Invalid Country Code");
        // Create a phone number with invalid country code format (invalid)
        String phone = "+1234";
        // Call checkCellPhoneNumber method with test phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is false since country code and digit format is incorrect
        assertFalse(result, "Phone number with invalid country code format should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber rejects phone with letters
    public void testCheckCellPhoneNumberWithLetters() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - With Letters");
        // Create a phone number containing letters (invalid)
        String phone = "+27abc1234567";
        // Call checkCellPhoneNumber method with test phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is false since phone number should contain only digits
        assertFalse(result, "Phone number with letters should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkCellPhoneNumber rejects empty string
    public void testCheckCellPhoneNumberEmptyString() {
        // Print test name to console for tracking test execution
        System.out.println("checkCellPhoneNumber - Empty String");
        // Create an empty string as test phone number (invalid)
        String phone = "";
        // Call checkCellPhoneNumber method with empty phone and store result
        boolean result = RegistrationAndLogin.checkCellPhoneNumber(phone);
        // Assert that result is false since empty string does not match phone format
        assertFalse(result, "Empty phone number should return false");
    }

    // ===== registerUser() TESTS =====
    
    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify registerUser succeeds with valid inputs
    public void testRegisterUserSuccess() {
        // Print test name to console for tracking test execution
        System.out.println("registerUser - Success");
        // Create a valid test username with underscore
        String username = "user_123";
        // Create a valid test password with all complexity requirements
        String password = "SecurePass123!";
        // Create a valid test phone number with country code
        String phone = "+27611234567";
        // Call registerUser method with valid parameters and store result
        String result = RegistrationAndLogin.registerUser(username, password, phone);
        // Assert that result equals success message indicating registration passed
        assertEquals("User successfully registered", result, "Valid registration should return success message");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify registerUser fails with invalid username
    public void testRegisterUserInvalidUsername() {
        // Print test name to console for tracking test execution
        System.out.println("registerUser - Invalid Username");
        // Create an invalid username without underscore
        String username = "invaliduser";
        // Create a valid test password
        String password = "SecurePass123!";
        // Create a valid test phone number
        String phone = "+27611234567";
        // Call registerUser method with invalid username and store result
        String result = RegistrationAndLogin.registerUser(username, password, phone);
        // Assert that result contains username error message
        assertTrue(result.contains("Username is not correctly formatted"), "Invalid username should return error message");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify registerUser fails with invalid password
    public void testRegisterUserInvalidPassword() {
        // Print test name to console for tracking test execution
        System.out.println("registerUser - Invalid Password");
        // Create a valid test username
        String username = "user_123";
        // Create an invalid password that is too short
        String password = "weak123";
        // Create a valid test phone number
        String phone = "+27611234567";
        // Call registerUser method with invalid password and store result
        String result = RegistrationAndLogin.registerUser(username, password, phone);
        // Assert that result contains password error message
        assertTrue(result.contains("Password is not correctly formatted"), "Invalid password should return error message");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify registerUser fails with invalid phone
    public void testRegisterUserInvalidPhone() {
        // Print test name to console for tracking test execution
        System.out.println("registerUser - Invalid Phone");
        // Create a valid test username
        String username = "user_123";
        // Create a valid test password
        String password = "SecurePass123!";
        // Create an invalid phone number without plus sign
        String phone = "27611234567";
        // Call registerUser method with invalid phone and store result
        String result = RegistrationAndLogin.registerUser(username, password, phone);
        // Assert that result contains phone error message
        assertTrue(result.contains("Cell phone number is incorrectly formatted"), "Invalid phone should return error message");
    }

    // ===== loginUser() TESTS =====
    
    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify loginUser succeeds with correct credentials
    public void testLoginUserSuccess() {
        // Print test name to console for tracking test execution
        System.out.println("loginUser - Success");
        // Set saved username to a test username
        RegistrationAndLogin.savedUsername = "user_123";
        // Set saved password to a test password
        RegistrationAndLogin.savedPassword = "SecurePass123!";
        
        // Call loginUser method with correct matching credentials and store result
        boolean result = RegistrationAndLogin.loginUser("user_123", "SecurePass123!");
        // Assert that result is true since credentials match the saved values
        assertTrue(result, "Correct credentials should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify loginUser fails with incorrect username
    public void testLoginUserInvalidUsername() {
        // Print test name to console for tracking test execution
        System.out.println("loginUser - Invalid Username");
        // Set saved username to a test username
        RegistrationAndLogin.savedUsername = "user_123";
        // Set saved password to a test password
        RegistrationAndLogin.savedPassword = "SecurePass123!";
        
        // Call loginUser method with incorrect username and store result
        boolean result = RegistrationAndLogin.loginUser("wrong_user", "SecurePass123!");
        // Assert that result is false since username does not match saved username
        assertFalse(result, "Incorrect username should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify loginUser fails with incorrect password
    public void testLoginUserInvalidPassword() {
        // Print test name to console for tracking test execution
        System.out.println("loginUser - Invalid Password");
        // Set saved username to a test username
        RegistrationAndLogin.savedUsername = "user_123";
        // Set saved password to a test password
        RegistrationAndLogin.savedPassword = "SecurePass123!";
        
        // Call loginUser method with correct username but incorrect password and store result
        boolean result = RegistrationAndLogin.loginUser("user_123", "WrongPass123!");
        // Assert that result is false since password does not match saved password
        assertFalse(result, "Incorrect password should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify loginUser fails with both username and password incorrect
    public void testLoginUserBothInvalid() {
        // Print test name to console for tracking test execution
        System.out.println("loginUser - Both Invalid");
        // Set saved username to a test username
        RegistrationAndLogin.savedUsername = "user_123";
        // Set saved password to a test password
        RegistrationAndLogin.savedPassword = "SecurePass123!";
        
        // Call loginUser method with both incorrect credentials and store result
        boolean result = RegistrationAndLogin.loginUser("wrong_user", "WrongPass123!");
        // Assert that result is false since neither credentials match saved values
        assertFalse(result, "Both incorrect credentials should return false");
    }

    // ===== returnLoginStatus() TESTS =====
    
    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify returnLoginStatus returns welcome message on success
    public void testReturnLoginStatusSuccess() {
        // Print test name to console for tracking test execution
        System.out.println("returnLoginStatus - Success");
        // Set saved username to a test username
        RegistrationAndLogin.savedUsername = "user_123";
        // Set saved password to a test password
        RegistrationAndLogin.savedPassword = "SecurePass123!";
        
        // Call returnLoginStatus method with correct credentials and store result
        String result = RegistrationAndLogin.returnLoginStatus("user_123", "SecurePass123!");
        // Assert that result equals the expected welcome message with username
        assertEquals("Welcome: user_123", result, "Successful login should return welcome message");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify returnLoginStatus returns error message on failure
    public void testReturnLoginStatusFailure() {
        // Print test name to console for tracking test execution
        System.out.println("returnLoginStatus - Failure");
        // Set saved username to a test username
        RegistrationAndLogin.savedUsername = "user_123";
        // Set saved password to a test password
        RegistrationAndLogin.savedPassword = "SecurePass123!";
        
        // Call returnLoginStatus method with incorrect credentials and store result
        String result = RegistrationAndLogin.returnLoginStatus("wrong_user", "WrongPass123!");
        // Assert that result equals the expected error message
        assertEquals("Username or password incorrect, please try again.", result, "Failed login should return error message");
    }
    
}