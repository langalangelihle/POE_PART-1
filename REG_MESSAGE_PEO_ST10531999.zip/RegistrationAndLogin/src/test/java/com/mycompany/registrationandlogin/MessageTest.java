package com.mycompany.registrationandlogin;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author lsphe
 */
// Declare the MessageTest class for unit testing the Message class
public class MessageTest {
    
    // Default constructor for MessageTest class
    public MessageTest() {
    }
    
    // Setup method that runs once before all test methods in the class
    @BeforeAll
    public static void setUpClass() {
    }
    
    // Teardown method that runs once after all test methods in the class
    @AfterAll
    public static void tearDownClass() {
    }
    
    // Setup method that runs before each individual test method
    @BeforeEach
    public void setUp() {
        // Clear all sent message ID array before each test to ensure clean state
        Message.sentMessageIDs.clear();
        // Clear all sent message hash array before each test to ensure clean state
        Message.sentMessageHashes.clear();
        // Clear all sent recipient array before each test to ensure clean state
        Message.sentRecipients.clear();
        // Clear all sent message text array before each test to ensure clean state
        Message.sentMessageTexts.clear();
        
        // Clear all stored message ID array before each test to ensure clean state
        Message.storedMessageIDs.clear();
        // Clear all stored message hash array before each test to ensure clean state
        Message.storedMessageHashes.clear();
        // Clear all stored recipient array before each test to ensure clean state
        Message.storedRecipients.clear();
        // Clear all stored message text array before each test to ensure clean state
        Message.storedMessageTexts.clear();
        
        // Reset the message ID counter back to 1000 before each test
        Message.messageIDCounter = 1000;
    }
    
    // Teardown method that runs after each individual test method
    @AfterEach
    public void tearDown() {
        // Clear sent message ID array after test execution
        Message.sentMessageIDs.clear();
        // Clear sent message hash array after test execution
        Message.sentMessageHashes.clear();
        // Clear sent recipient array after test execution
        Message.sentRecipients.clear();
        // Clear sent message text array after test execution
        Message.sentMessageTexts.clear();
        
        // Clear stored message ID array after test execution
        Message.storedMessageIDs.clear();
        // Clear stored message hash array after test execution
        Message.storedMessageHashes.clear();
        // Clear stored recipient array after test execution
        Message.storedRecipients.clear();
        // Clear stored message text array after test execution
        Message.storedMessageTexts.clear();
        
        // Reset message ID counter to 1000 after test execution
        Message.messageIDCounter = 1000;
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkMessageLength works with valid message (50 chars)
    public void testCheckMessageLengthValid() {
        // Print test name to console for tracking test execution
        System.out.println("checkMessageLength - Valid (50 chars)");
        // Create a test message with 21 characters
        String message = "Did you get the cake?";
        // Call the checkMessageLength method and store the result
        boolean result = Message.checkMessageLength(message);
        // Assert that the result is true since message is under 250 characters
        assertTrue(result, "Message with 21 characters should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkMessageLength works with exactly 250 characters
    public void testCheckMessageLengthExactly250() {
        // Print test name to console for tracking test execution
        System.out.println("checkMessageLength - Exactly 250 Characters");
        // Create a message string with exactly 250 'a' characters
        String message = "a".repeat(250);
        // Call the checkMessageLength method and store the result
        boolean result = Message.checkMessageLength(message);
        // Assert that result is true since 250 is the maximum allowed length
        assertTrue(result, "Message with exactly 250 characters should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkMessageLength rejects messages longer than 250 characters
    public void testCheckMessageLengthTooLong() {
        // Print test name to console for tracking test execution
        System.out.println("checkMessageLength - Too Long (251 chars)");
        // Create a message string with 251 'a' characters (exceeds limit)
        String message = "a".repeat(251);
        // Call the checkMessageLength method and store the result
        boolean result = Message.checkMessageLength(message);
        // Assert that result is false since message exceeds 250 character limit
        assertFalse(result, "Message with 251 characters should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkMessageLength handles empty message string
    public void testCheckMessageLengthEmpty() {
        // Print test name to console for tracking test execution
        System.out.println("checkMessageLength - Empty String");
        // Create an empty message string
        String message = "";
        // Call the checkMessageLength method and store the result
        boolean result = Message.checkMessageLength(message);
        // Assert that result is true since empty string (0 chars) is within limit
        assertTrue(result, "Empty message should return true (0 <= 250)");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkRecipientCell works with valid phone number
    public void testCheckRecipientCellValid() {
        // Print test name to console for tracking test execution
        System.out.println("checkRecipientCell - Valid");
        // Create a valid South African phone number string
        String recipient = "+27634432988";
        // Call the checkRecipientCell method and store the result
        boolean result = Message.checkRecipientCell(recipient);
        // Assert that result is true since phone number is in correct format
        assertTrue(result, "Valid phone number should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkRecipientCell works with different country code
    public void testCheckRecipientCellValidDifferentCountry() {
        // Print test name to console for tracking test execution
        System.out.println("checkRecipientCell - Valid Different Country");
        // Create a valid UK phone number string
        String recipient = "+441234567890";
        // Call the checkRecipientCell method and store the result
        boolean result = Message.checkRecipientCell(recipient);
        // Assert that result is true since UK phone number is valid format
        assertTrue(result, "Valid UK phone number should return true");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkRecipientCell rejects phone without plus sign
    public void testCheckRecipientCellMissingPlus() {
        // Print test name to console for tracking test execution
        System.out.println("checkRecipientCell - Missing Plus");
        // Create a phone number string without the required plus sign
        String recipient = "27634432988";
        // Call the checkRecipientCell method and store the result
        boolean result = Message.checkRecipientCell(recipient);
        // Assert that result is false since plus sign is required
        assertFalse(result, "Phone without + should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify checkRecipientCell rejects phone with too few digits
    public void testCheckRecipientCellTooShort() {
        // Print test name to console for tracking test execution
        System.out.println("checkRecipientCell - Too Short");
        // Create a phone number string with insufficient digits
        String recipient = "+276344329";
        // Call the checkRecipientCell method and store the result
        boolean result = Message.checkRecipientCell(recipient);
        // Assert that result is false since phone does not have required digit count
        assertFalse(result, "Phone with too few digits should return false");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify createMessageHash produces correct format
    public void testCreateMessageHashValid() {
        // Print test name to console for tracking test execution
        System.out.println("createMessageHash - Valid");
        // Create test message ID string
        String messageID = "1001";
        // Set the message number to 1
        int numMessages = 1;
        // Create test message text
        String message = "Did you get the cake?";
        // Call createMessageHash method with test parameters and store result
        String result = Message.createMessageHash(messageID, numMessages, message);
        // Assert that result matches expected hash format (first 2 of ID:count:first word:last word)
        assertEquals("10:1:Did:cake?", result, "Hash should be formatted correctly");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify createMessageHash works for second message
    public void testCreateMessageHashSecondMessage() {
        // Print test name to console for tracking test execution
        System.out.println("createMessageHash - Second Message");
        // Create test message ID for second message
        String messageID = "1002";
        // Set the message number to 2
        int numMessages = 2;
        // Create test message text with multiple words
        String message = "Where are you? You are late!";
        // Call createMessageHash method with test parameters and store result
        String result = Message.createMessageHash(messageID, numMessages, message);
        // Assert that hash contains first 2 chars of ID and first/last words correctly
        assertEquals("10:2:Where:late!", result, "Hash should contain first 2 chars of ID and first/last words");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify createMessageHash handles single word messages
    public void testCreateMessageHashSingleWord() {
        // Print test name to console for tracking test execution
        System.out.println("createMessageHash - Single Word Message");
        // Create test message ID
        String messageID = "1003";
        // Set the message number to 1
        int numMessages = 1;
        // Create test message with single word only
        String message = "Hello";
        // Call createMessageHash method with test parameters and store result
        String result = Message.createMessageHash(messageID, numMessages, message);
        // Assert that single word appears as both first and last word in hash
        assertEquals("10:1:Hello:Hello", result, "Single word should appear as both first and last");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify generateMessageID creates first ID correctly
    public void testGenerateMessageIDFirst() {
        // Print test name to console for tracking test execution
        System.out.println("generateMessageID - First ID");
        // Call generateMessageID method and store the result
        String result = Message.generateMessageID();
        // Assert that first generated ID is 1001
        assertEquals("1001", result, "First generated ID should be 1001");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify generateMessageID creates sequential IDs
    public void testGenerateMessageIDSequential() {
        // Print test name to console for tracking test execution
        System.out.println("generateMessageID - Sequential IDs");
        // Call generateMessageID first time and store result
        String id1 = Message.generateMessageID();
        // Call generateMessageID second time and store result
        String id2 = Message.generateMessageID();
        // Call generateMessageID third time and store result
        String id3 = Message.generateMessageID();
        
        // Assert that first ID is 1001
        assertEquals("1001", id1, "First ID should be 1001");
        // Assert that second ID is 1002
        assertEquals("1002", id2, "Second ID should be 1002");
        // Assert that third ID is 1003
        assertEquals("1003", id3, "Third ID should be 1003");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify returnTotalMessagesSent returns 0 when no messages
    public void testReturnTotalMessagesSentZero() {
        // Print test name to console for tracking test execution
        System.out.println("returnTotalMessagesSent - Zero Messages");
        // Call returnTotalMessagesSent method and store the result
        int result = Message.returnTotalMessagesSent();
        // Assert that result is 0 since no messages have been sent
        assertEquals(0, result, "Should return 0 when no messages sent");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify returnTotalMessagesSent counts added messages correctly
    public void testReturnTotalMessagesSentAfterAdding() {
        // Print test name to console for tracking test execution
        System.out.println("returnTotalMessagesSent - After Adding Messages");
        // Add first message ID to sent messages array
        Message.sentMessageIDs.add("1001");
        // Add second message ID to sent messages array
        Message.sentMessageIDs.add("1002");
        // Add third message ID to sent messages array
        Message.sentMessageIDs.add("1003");
        
        // Call returnTotalMessagesSent method and store the result
        int result = Message.returnTotalMessagesSent();
        // Assert that result equals 3 since three messages were added
        assertEquals(3, result, "Should return count of sent messages");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to populate and verify Test Data Message 1 (Sent)
    public void testPopulateTestDataMessage1() {
        // Print test name to console for tracking test execution
        System.out.println("Populate Test Data - Message 1 (Sent)");
        // Add message ID 1001 to sent message IDs array
        Message.sentMessageIDs.add("1001");
        // Add recipient phone number to sent recipients array
        Message.sentRecipients.add("+27634432988");
        // Add message text to sent message texts array
        Message.sentMessageTexts.add("Did you get the cake?");
        // Add message hash to sent message hashes array
        Message.sentMessageHashes.add("10:1:Did:cake?");
        
        // Assert that sent message IDs array now has 1 element
        assertEquals(1, Message.sentMessageIDs.size(), "Sent message should be added");
        // Assert that the first recipient matches the expected value
        assertEquals("+27634432988", Message.sentRecipients.get(0), "Recipient should match");
        // Assert that the message text matches the expected value
        assertEquals("Did you get the cake?", Message.sentMessageTexts.get(0), "Message text should match");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to populate and verify Test Data Message 2 (Stored)
    public void testPopulateTestDataMessage2() {
        // Print test name to console for tracking test execution
        System.out.println("Populate Test Data - Message 2 (Stored)");
        // Add message ID 1002 to stored message IDs array
        Message.storedMessageIDs.add("1002");
        // Add recipient phone number to stored recipients array
        Message.storedRecipients.add("+27634466967");
        // Add message text to stored message texts array
        Message.storedMessageTexts.add("Where are you? You are late! I have asked you to be on time");
        // Add message hash to stored message hashes array
        Message.storedMessageHashes.add("10:1:Where:time");
        
        // Assert that stored message IDs array now has 1 element
        assertEquals(1, Message.storedMessageIDs.size(), "Stored message should be added");
        // Assert that the first recipient matches the expected value
        assertEquals("+27634466967", Message.storedRecipients.get(0), "Recipient should match");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to populate and verify Test Data Message 5 (Stored)
    public void testPopulateTestDataMessage5() {
        // Print test name to console for tracking test execution
        System.out.println("Populate Test Data - Message 5 (Stored)");
        // Add message ID 1005 to stored message IDs array
        Message.storedMessageIDs.add("1005");
        // Add recipient phone number to stored recipients array
        Message.storedRecipients.add("+27634466967");
        // Add message text to stored message texts array
        Message.storedMessageTexts.add("Ok, I am leaving without you");
        // Add message hash to stored message hashes array
        Message.storedMessageHashes.add("10:2:Ok,:you");
        
        // Assert that stored message IDs array now has 1 element
        assertEquals(1, Message.storedMessageIDs.size(), "Stored message should be added");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify correct identification of longest message
    public void testLongestMessageIdentification() {
        // Print test name to console for tracking test execution
        System.out.println("Longest Message - Identification");
        
        // Add first message ID to stored messages array
        Message.storedMessageIDs.add("1001");
        // Add second message ID to stored messages array
        Message.storedMessageIDs.add("1002");
        // Add third message ID to stored messages array
        Message.storedMessageIDs.add("1003");
        
        // Add first message text (short message) to array
        Message.storedMessageTexts.add("Did you get the cake?");
        // Add second message text (longest message) to array
        Message.storedMessageTexts.add("Where are you? You are late! I have asked you to be on time");
        // Add third message text (medium message) to array
        Message.storedMessageTexts.add("Ok, I am leaving without you");
        
        // Add first recipient to array
        Message.storedRecipients.add("+27634432988");
        // Add second recipient to array
        Message.storedRecipients.add("+27634466967");
        // Add third recipient to array
        Message.storedRecipients.add("+27634466967");
        
        // Add first message hash to array
        Message.storedMessageHashes.add("10:1:Did:cake?");
        // Add second message hash to array
        Message.storedMessageHashes.add("10:2:Where:time");
        // Add third message hash to array
        Message.storedMessageHashes.add("10:3:Ok,:you");
        
        // Initialize variable to store longest message found (empty string)
        String longestMessage = "";
        // Initialize variable to track index of longest message
        int longestIndex = 0;
        
        // Loop through each message in stored messages array
        for (int i = 0; i < Message.storedMessageTexts.size(); i++) {
            // Check if current message length is greater than longest found so far
            if (Message.storedMessageTexts.get(i).length() > longestMessage.length()) {
                // Update longestMessage with current message text
                longestMessage = Message.storedMessageTexts.get(i);
                // Update longestIndex to track which message is longest
                longestIndex = i;
            }
        }
        
        // Assert that longest message matches the expected longest message
        assertEquals("Where are you? You are late! I have asked you to be on time", longestMessage, "Should identify correct longest message");
        // Assert that longest message index is 1 (second message)
        assertEquals(1, longestIndex, "Longest message should be at index 1");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify searching for message by ID works correctly
    public void testSearchStoredMessageByID() {
        // Print test name to console for tracking test execution
        System.out.println("Search Message - By ID");
        
        // Add message ID 1002 to stored messages array
        Message.storedMessageIDs.add("1002");
        // Add recipient to stored recipients array
        Message.storedRecipients.add("+27634466967");
        // Add message text to stored messages array
        Message.storedMessageTexts.add("Where are you? You are late!");
        
        // Create string variable with ID to search for
        String searchID = "1002";
        // Initialize variable to store found message index (-1 = not found)
        int foundIndex = -1;
        
        // Loop through all stored message IDs to find matching one
        for (int i = 0; i < Message.storedMessageIDs.size(); i++) {
            // Check if current message ID matches search ID
            if (Message.storedMessageIDs.get(i).equals(searchID)) {
                // Set foundIndex to current position
                foundIndex = i;
                // Exit loop since message was found
                break;
            }
        }
        
        // Assert that foundIndex is 0 (first and only element)
        assertEquals(0, foundIndex, "Should find message by ID");
        // Assert that recipient at found index matches expected value
        assertEquals("+27634466967", Message.storedRecipients.get(foundIndex), "Should return correct recipient");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify searching for all messages for particular recipient
    public void testSearchMessagesForRecipient() {
        // Print test name to console for tracking test execution
        System.out.println("Search Messages - By Recipient");
        
        // Add first message ID to stored messages array
        Message.storedMessageIDs.add("1002");
        // Add second message ID to stored messages array
        Message.storedMessageIDs.add("1005");
        
        // Add first recipient to stored recipients array
        Message.storedRecipients.add("+27634466967");
        // Add second recipient (same as first) to stored recipients array
        Message.storedRecipients.add("+27634466967");
        
        // Add first message text to array
        Message.storedMessageTexts.add("Where are you? You are late!");
        // Add second message text to array
        Message.storedMessageTexts.add("Ok, I am leaving without you");
        
        // Create string variable with recipient number to search for
        String searchRecipient = "+27634466967";
        // Initialize counter for matching recipients found
        int count = 0;
        
        // Loop through each recipient in stored recipients array
        for (String recipient : Message.storedRecipients) {
            // Check if current recipient matches search recipient
            if (recipient.equals(searchRecipient)) {
                // Increment count since matching recipient found
                count++;
            }
        }
        
        // Assert that count equals 2 since two messages have this recipient
        assertEquals(2, count, "Should find all messages for recipient");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify deleting message by hash works correctly
    public void testDeleteMessageByHash() {
        // Print test name to console for tracking test execution
        System.out.println("Delete Message - By Hash");
        
        // Add message ID to stored messages array
        Message.storedMessageIDs.add("1002");
        // Add message hash to stored message hashes array
        Message.storedMessageHashes.add("10:1:Where:time");
        // Add recipient to stored recipients array
        Message.storedRecipients.add("+27634466967");
        // Add message text to stored messages array
        Message.storedMessageTexts.add("Where are you? You are late!");
        
        // Create string variable with hash to search for and delete
        String searchHash = "10:1:Where:time";
        // Store initial size of stored message IDs array
        int initialSize = Message.storedMessageIDs.size();
        
        // Loop through all stored message hashes to find matching one
        for (int i = 0; i < Message.storedMessageHashes.size(); i++) {
            // Check if current hash matches search hash (case-insensitive comparison)
            if (Message.storedMessageHashes.get(i).equalsIgnoreCase(searchHash)) {
                // Remove message ID at matching index
                Message.storedMessageIDs.remove(i);
                // Remove message hash at matching index
                Message.storedMessageHashes.remove(i);
                // Remove recipient at matching index
                Message.storedRecipients.remove(i);
                // Remove message text at matching index
                Message.storedMessageTexts.remove(i);
                // Exit loop after deletion
                break;
            }
        }
        
        // Assert that array size decreased by 1 after deletion
        assertEquals(initialSize - 1, Message.storedMessageIDs.size(), "Message should be deleted");
    }

    // Test annotation indicating this method is a unit test
    @Test
    // Test method to verify all arrays are properly populated for report
    public void testStoredMessagesReportPopulation() {
        // Print test name to console for tracking test execution
        System.out.println("Display Report - Full Details");
        
        // Add first message ID to stored messages array
        Message.storedMessageIDs.add("1002");
        // Add second message ID to stored messages array
        Message.storedMessageIDs.add("1005");
        
        // Add first message hash to array
        Message.storedMessageHashes.add("10:1:Where:time");
        // Add second message hash to array
        Message.storedMessageHashes.add("10:2:Ok,:you");
        
        // Add first recipient to array
        Message.storedRecipients.add("+27634466967");
        // Add second recipient to array
        Message.storedRecipients.add("+27634466967");
        
        // Add first message text to array
        Message.storedMessageTexts.add("Where are you? You are late!");
        // Add second message text to array
        Message.storedMessageTexts.add("Ok, I am leaving without you");
        
        // Assert that Message ID array contains 2 items
        assertEquals(2, Message.storedMessageIDs.size(), "Message ID array should contain 2 items");
        // Assert that Message Hash array contains 2 items
        assertEquals(2, Message.storedMessageHashes.size(), "Message Hash array should contain 2 items");
        // Assert that Recipient array contains 2 items
        assertEquals(2, Message.storedRecipients.size(), "Recipient array should contain 2 items");
        // Assert that Message Text array contains 2 items
        assertEquals(2, Message.storedMessageTexts.size(), "Message Text array should contain 2 items");
    }
    
}